import { combineReducers } from 'redux';
import HeadUiReducer from './headerUi';

const Reducers = combineReducers({
  HeadUiReducer
});

export default Reducers;
