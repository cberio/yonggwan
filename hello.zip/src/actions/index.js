import * as types from './actionType';

export function getAlert () {
  return {
    type : types.A
  }
}
