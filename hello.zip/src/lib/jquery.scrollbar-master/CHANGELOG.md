<h4>v0.2.11 (20160803)</h4>
Fix bug with Mozilla FireFox

<h4>v0.2.10 (20151216)</h4>
Increase version to update bower repository

<h4>v0.2.9 (20151022)</h4>
Increase version to update bower repository

<h4>v0.2.8 (20150723)</h4>
Add Meteor/Node modules support<br>
Fix bug when removed content does not update element's height<br>
Fix bug with textarea in non-webkit browsers<br>
Update webkit-based browser detection to ignore Microsoft Edge browser<br>
Change default values for ignoreMobile/ignoreOverlay to false<br/>

<h4>v0.2.7 (20150122)</h4>
Small fixes<br>

<h4>v0.2.6 (20141124)</h4>
Re-register plugin in jQuery plugins repository<br>

<h4>v0.2.5 (20141119)</h4>
Add option ignoreOverlay with default value true<br>
Fix webkit-based browser detection<br>
Ignore Firefox in Mac OS (cannot hide native scrollbars)<br>

<h4>v0.2.4 (20140715)</h4>
Add textarea support<br>

<h4>v0.2.3 (20140703)</h4>
Default options can be overwritten via default global object<br>
Fix bug with visible native scrollbars when page is zoomed<br>
Add onScroll callback<br>
Add Angular.JS directive<br>

<h4>v0.2.2 (20140411)</h4>
Fix default options issue with multiple scrollbars initialization<br>

<h4>v0.2.1 (20140323)</h4>
Update CSS classes for custom scroll elements<br>
Set option ignoreMobile to true by default<br>
Small CSS/JS fixes<br>

<h4>v0.2.0 (20140312)</h4>
Add onUpdate callback<br>
Manage scrollbar visibility via CSS classes<br>

<h4>v0.1.9 (20140310)</h4>
Fix bug with inner div height 100%<br>
Add option autoUpdate<br>

<h4>v0.1.8 (20140308)</h4>
Fix bug with visible horizontal scrollbar if content height is less than container height<br>

<h4>v0.1.7 (20140307)</h4>
Add hack for IE9-11 with 1px diff between visible and scrollable height<br>
Fix bug with second-time plugin initialization<br>
Remove warnings from IDE<br>

<h4>v0.1.4 (20130430)</h4>
Add horizontal scrollbar handler<br>
Add option disableBodyScroll<br>

<h4>v0.1.3 (20130423)</h4>
Improve scroll simulation<br>
Fix webkit bug with text selection<br>

<h4>v0.1.2 (20130422)</h4>
Handle mousedown instead of click on scrollbar track/arrows<br>

<h4>v0.0.2 (20130413)</h4>
First version<br>
