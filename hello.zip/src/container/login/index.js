import React, { Component } from 'react';

export class Login extends Component {
  render() {
    return (
      <div>
        <h2>Here is Login page</h2>
      </div>
    );
  }
}
